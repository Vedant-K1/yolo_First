const express = require('express');
const app = express();
const upload = require('express-fileupload')
const fs = require('fs');

app.set('view engine', 'ejs');
app.use(express.static('public'))
app.use(upload())


app.get('/', (req, res) => {
  res.render('home');
});

app.get('/contactus', (req, res) => {
    res.render('contactus');
});

app.get('/working', (req, res) => {
    res.render('working');
});

app.get('/about', (req, res) => {
    res.render('about');
});

app.get('/components', (req, res) => {
    res.render('components');
});

app.get('/uploadFile', (req,res) => {
    res.render('uploadFile');
});

app.post('/upload', (req,res) => {
    if(req.files) {
        // console.log(req.files);
        var file = req.files.file;
        var fileName = file.name;
        console.log('filename', fileName);

        file.mv('./public/uploads/'+fileName, function(err) {
            if (err)  {
                throw err;
            }
            else {
                
                fs.rename('./public/uploads/'+fileName,'./public/uploads/raw1.mp4', () => {
                    console.log("\nFile Renamed!\n");
                });
            }
        });

    }
    res.redirect('/working');
});

app.listen(80, () => {
  console.log(`Example app listening on port 80`);
});